/* ===== Assistant chat widget + order workflow: runs in the browser, no external AI ===== */
const ORDER_RE = /\bCF-\d{6}-[A-Z0-9]{4}\b/i;
const ORDERS_KEY = "cf_orders", NOTIF_KEY = "cf_notifs";

/* ---- storage (localStorage with in-memory fallback) ---- */
const store = (() => {
  const mem = {};
  return {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (_) { return k in mem ? mem[k] : d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) { mem[k] = v; } }
  };
})();

/* ---- date / time helpers ---- */
const pad2 = n => String(n).padStart(2, "0");
function todayStr() { const d = new Date(); return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()); }
function slotMinutes(t) {
  const m = /^(\d{1,2}):(\d{2})\s*(AM|PM)$/i.exec(t); if (!m) return null;
  let h = (+m[1]) % 12; if (m[3].toUpperCase() === "PM") h += 12;
  return h * 60 + (+m[2]);
}
function slotDate(dateStr, t) {
  const [y, mo, d] = dateStr.split("-").map(Number), mins = slotMinutes(t);
  return new Date(y, mo - 1, d, Math.floor(mins / 60), mins % 60);
}
function fmtDate(s) {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}
function fmtDur(min) {
  if (min < 60) return min + " min";
  const h = Math.floor(min / 60);
  if (h < 24) return h + " h " + (min % 60) + " min";
  const d = Math.floor(h / 24);
  return d + " day" + (d > 1 ? "s" : "") + " " + (h % 24) + " h";
}
function validDate(y, m, d) { const t = new Date(y, m - 1, d); return t.getFullYear() === y && t.getMonth() === m - 1 && t.getDate() === d; }
function parseDate(text) {
  const q = text.toLowerCase();
  if (/\btoday\b/.test(q)) return todayStr();
  if (/\btomorrow\b/.test(q)) { const d = new Date(); d.setDate(d.getDate() + 1); return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()); }
  let m = /(\d{4})-(\d{1,2})-(\d{1,2})/.exec(text);
  if (m && validDate(+m[1], +m[2], +m[3])) return m[1] + "-" + pad2(+m[2]) + "-" + pad2(+m[3]);
  m = /(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/.exec(text);
  if (m && validDate(+m[3], +m[2], +m[1])) return m[3] + "-" + pad2(+m[2]) + "-" + pad2(+m[1]);
  return null;
}
function parseSlot(text) {
  const m = /(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i.exec(text); if (!m) return null;
  let h = +m[1]; const min = +(m[2] || 0), ap = (m[3] || "").toLowerCase();
  const tries = [];
  if (ap === "pm") tries.push((h % 12) + 12);
  else if (ap === "am") tries.push(h % 12);
  else { tries.push(h); if (h <= 12) tries.push((h % 12) + 12); }
  for (const hh of tries) { const s = SLOTS.find(x => slotMinutes(x) === hh * 60 + min); if (s) return s; }
  return null;
}

/* ---- orders ---- */
const getOrders = () => store.get(ORDERS_KEY, []);
const saveOrders = o => store.set(ORDERS_KEY, o);
const findOrder = id => getOrders().find(o => o.id === id);
function updateOrder(id, patch) {
  const all = getOrders(), i = all.findIndex(o => o.id === id);
  if (i < 0) return null;
  all[i] = { ...all[i], ...patch }; saveOrders(all); return all[i];
}
function newOrderId() {
  const A = "ABCDEFGHJKMNPQRSTUVWXYZ23456789", d = new Date();
  const ymd = String(d.getFullYear()).slice(2) + pad2(d.getMonth() + 1) + pad2(d.getDate());
  const all = getOrders(); let id;
  do { id = "CF-" + ymd + "-" + Array.from({ length: 4 }, () => A[Math.floor(Math.random() * A.length)]).join(""); }
  while (all.some(o => o.id === id));
  return id;
}
function createOrder(d) {
  const o = {
    id: newOrderId(), service: d.service, serviceName: d.serviceName, date: d.date, slot: d.slot,
    name: d.name, phone: d.phone, email: d.email, notes: d.notes || "",
    status: "Pending confirmation", reschedules: 0, delayedByStudio: false, delayNotified: false,
    createdAt: Date.now(), history: []
  };
  saveOrders([...getOrders(), o]);
  notify(o.id, "Booking received", o.serviceName + " on " + fmtDate(o.date) + ", " + o.slot + ". Order ID: " + o.id + ". We will confirm on WhatsApp.");
  return o;
}

/* ---- workflow steps 2 and 3 ---- */
function checkForm(o) {
  const miss = [];
  if (!SERVICES.some(s => s.code === o.service)) miss.push("service");
  if (!o.date) miss.push("date");
  if (!o.slot) miss.push("time slot");
  if (!o.name) miss.push("name");
  if (!/^[6-9]\d{9}$/.test(o.phone || "")) miss.push("valid mobile number");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(o.email || "")) miss.push("valid email");
  return { ok: miss.length === 0, miss, noEventDetails: !o.notes };
}
const TERMINAL = ["Completed", "Cancelled", "Refund requested"];
function delayInfo(o) {
  const sched = slotDate(o.date, o.slot);
  const active = !TERMINAL.includes(o.status);
  const overdueMin = Math.max(0, Math.floor((Date.now() - sched.getTime()) / 60000));
  const delayed = active && (o.delayedByStudio || overdueMin > POLICY.graceMinutes);
  return { delayed, overdueMin, sched, active };
}
function eligibility(o, d) {
  const r = { reschedule: { ok: false, why: "" }, refund: { ok: false, why: "" } };
  if (!d.active) {
    r.reschedule.why = r.refund.why = "the order is already " + o.status.toLowerCase() + ".";
    return r;
  }
  const noticeH = (d.sched - Date.now()) / 36e5;
  if (o.reschedules >= POLICY.maxReschedules) r.reschedule.why = "the maximum of " + POLICY.maxReschedules + " time changes was already used.";
  else if (d.delayed) { r.reschedule.ok = true; r.reschedule.why = "the order is delayed."; }
  else if (noticeH < POLICY.minNoticeHours) r.reschedule.why = "changes need at least " + POLICY.minNoticeHours + " hours' notice before the shoot.";
  else { r.reschedule.ok = true; r.reschedule.why = "more than " + POLICY.minNoticeHours + " hours before the shoot."; }

  if (!d.delayed) r.refund.why = "refunds apply only to delayed orders.";
  else if (o.delayedByStudio || d.overdueMin >= POLICY.refundAfterDelayHours * 60) r.refund.ok = true, r.refund.why = "the order is delayed beyond " + POLICY.refundAfterDelayHours + " hours or was flagged by the studio.";
  else r.refund.why = "the delay is under " + POLICY.refundAfterDelayHours + " hours; you can reschedule instead.";
  return r;
}
function freeSlotsFor(dateStr, exceptId) {
  const taken = getOrders()
    .filter(o => o.id !== exceptId && o.date === dateStr && !["Cancelled", "Refund requested", "Completed"].includes(o.status))
    .map(o => o.slot);
  const now = Date.now();
  return SLOTS.filter(t => !BOOKED.includes(t) && !taken.includes(t) && slotDate(dateStr, t).getTime() > now);
}
function workflowReport(o) {
  const f = checkForm(o), d = delayInfo(o), e = eligibility(o, d);
  const parts = [
    "Step 1 · Order found\n" + o.id + " · " + o.serviceName,
    "Step 2 · Form details\nName: " + o.name + "\nMobile: " + o.phone + "\nEmail: " + o.email +
      "\nSchedule: " + fmtDate(o.date) + ", " + o.slot + "\nStatus: " + o.status + "\n" +
      (f.ok ? "✓ All required details are complete." + (f.noEventDetails ? " (Event details were left blank.)" : "")
            : "✗ Missing or invalid: " + f.miss.join(", ")),
    "Step 3 · Schedule check\n" + (d.delayed
      ? "⚠ Delayed" + (d.overdueMin ? " by " + fmtDur(d.overdueMin) : " (flagged by the studio)") + "."
      : d.active ? "✓ On schedule." : "Order is " + o.status.toLowerCase() + "."),
    "Reschedule: " + (e.reschedule.ok ? "eligible" : "not eligible, " + e.reschedule.why) +
      "\nRefund: " + (e.refund.ok ? "eligible" : "not eligible, " + e.refund.why)
  ];
  const chips = [];
  if (e.reschedule.ok) chips.push("Reschedule");
  if (e.refund.ok) chips.push("Request refund");
  return { text: parts.join("\n\n"), chips };
}
/* Step 5 for delayed orders: tell the customer once */
function checkDelayNotify(o) {
  const d = delayInfo(o);
  if (d.delayed && !o.delayNotified) {
    updateOrder(o.id, { delayNotified: true });
    notify(o.id, "Order " + o.id + " is delayed", "Open the assistant to reschedule or check refund eligibility.");
  }
}

/* ---- in-app notifications (step 5) ---- */
const chatFab = $("#chatFab"), chatPanel = $("#chatPanel"), chatLog = $("#chatLog");
const chatForm = $("#chatForm"), chatInput = $("#chatInput");
const toastWrap = $("#toastWrap"), chatBadge = $("#chatBadge");
const getNotifs = () => store.get(NOTIF_KEY, []);
function notify(orderId, title, body) {
  const n = { id: Date.now() + Math.random().toString(36).slice(2, 6), orderId, title, body, ts: Date.now(), read: false };
  store.set(NOTIF_KEY, [...getNotifs(), n]);
  showToast(n); updateBadge();
}
function showToast(n) {
  const t = document.createElement("div");
  t.className = "toast"; t.setAttribute("role", "status");
  const b = document.createElement("b"); b.textContent = n.title;
  const s = document.createElement("span"); s.textContent = n.body;
  t.append(b, s);
  t.addEventListener("click", () => { t.remove(); openChat(); ask("notifications"); });
  toastWrap.appendChild(t);
  setTimeout(() => t.remove(), 8000);
}
function updateBadge() {
  const c = getNotifs().filter(n => !n.read).length;
  chatBadge.hidden = c === 0; chatBadge.textContent = c > 9 ? "9+" : String(c);
}
function notificationsText() {
  const all = getNotifs();
  if (!all.length) return "No notifications yet. You will get one here when you book, and whenever an order is delayed, rescheduled or a refund is requested.";
  store.set(NOTIF_KEY, all.map(n => ({ ...n, read: true }))); updateBadge();
  return "🔔 Notifications\n" + all.slice(-6).reverse().map(n =>
    "• " + new Date(n.ts).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" }) +
    " · " + n.title + "\n  " + n.body).join("\n");
}

/* ---- chat engine ---- */
const CONTACT_TEXT = "Mobile / WhatsApp: " + BUSINESS.mobile + "\nEmail: " + BUSINESS.email;
const ctx = { order: null, want: null, mode: null, newDate: null };

function addBubble(text, who) {
  const b = document.createElement("div");
  b.className = "bubble " + who;
  b.textContent = text;
  chatLog.appendChild(b);
  chatLog.scrollTop = chatLog.scrollHeight;
}
function addChips(list) {
  const row = document.createElement("div");
  row.className = "chat-quick chips-row";
  list.forEach(c => {
    const label = typeof c === "string" ? c : c.label;
    const b = document.createElement("button");
    b.type = "button"; b.textContent = label;
    b.addEventListener("click", () => { if (c.url) window.open(c.url, "_blank", "noopener"); else ask(label); });
    row.appendChild(b);
  });
  chatLog.appendChild(row);
  chatLog.scrollTop = chatLog.scrollHeight;
}
function freeSlots() {
  return SLOTS.filter(t => !BOOKED.includes(t));
}
function waLink(msg) { return "https://wa.me/91" + BUSINESS.mobile + "?text=" + encodeURIComponent(msg); }

function needOrder(want) {
  ctx.want = want;
  const ids = getOrders().slice(-3).map(o => o.id).reverse();
  return {
    text: "Step 1 · Please send your order ID. It looks like CF-261121-A7K2 and is shown when you book a slot." + (ids.length ? "\nOrders saved on this device:" : ""),
    chips: ids
  };
}
function startReschedule(o) {
  const d = delayInfo(o), e = eligibility(o, d);
  if (!e.reschedule.ok) { ctx.mode = null; return "Step 3 · " + o.id + " cannot be rescheduled here: " + e.reschedule.why + "\nPlease contact us on WhatsApp " + BUSINESS.mobile + "."; }
  ctx.mode = "date";
  return {
    text: "Step 3 · " + o.id + " is eligible to reschedule (" + (POLICY.maxReschedules - o.reschedules) + " change(s) left).\nStep 4 · Send the new date, for example 25/11/2026, or tap a choice. Say \"stop\" to cancel.",
    chips: ["Today", "Tomorrow"]
  };
}
function startRefund(o) {
  const d = delayInfo(o), e = eligibility(o, d);
  if (!e.refund.ok) return "Refund check for " + o.id + ": not eligible, " + e.refund.why + (e.reschedule.ok ? "\nYou can reschedule instead. Type \"reschedule\"." : "");
  ctx.mode = "refund";
  return { text: "Refund check for " + o.id + ": eligible, " + e.refund.why + "\nShall I record a refund request?", chips: ["Yes, request refund", "No"] };
}
function runIntent(o, want) {
  ctx.order = o.id; ctx.want = null;
  if (want === "reschedule") return startReschedule(o);
  if (want === "refund") return startRefund(o);
  const r = workflowReport(o); checkDelayNotify(o);
  return r;
}
function flow(text, q) {
  const o = findOrder(ctx.order);
  if (!o) { ctx.mode = null; return null; }
  if (ctx.mode === "date") {
    const nd = parseDate(text);
    if (!nd) { if (/(service|contact|notification|how to book|slots|after booking|about)/.test(q)) { ctx.mode = null; return null; }
      return { text: "I couldn't read that date. Send it like 25/11/2026 or 2026-11-25, or say tomorrow.", chips: ["Today", "Tomorrow"] }; }
    if (nd < todayStr()) return "That date has passed. Please send today's date or a future date.";
    const free = freeSlotsFor(nd, o.id);
    if (!free.length) return "No open slots on " + fmtDate(nd) + ". Please try another date.";
    ctx.newDate = nd; ctx.mode = "slot";
    return { text: "Open slots on " + fmtDate(nd) + ": " + free.join(", ") + ".\nWhich time would you like?", chips: free };
  }
  if (ctx.mode === "slot") {
    const slot = parseSlot(text), free = freeSlotsFor(ctx.newDate, o.id);
    if (!slot || !free.includes(slot)) {
      if (/(service|contact|notification|how to book|slots|after booking|about)/.test(q)) { ctx.mode = null; return null; }
      return { text: "Please pick one of the open slots: " + free.join(", ") + ".", chips: free };
    }
    if (ctx.newDate === o.date && slot === o.slot) return "That is already your current time. Please choose a different slot.";
    const from = fmtDate(o.date) + ", " + o.slot, to = fmtDate(ctx.newDate) + ", " + slot;
    updateOrder(o.id, {
      date: ctx.newDate, slot, status: "Rescheduled", reschedules: o.reschedules + 1,
      delayedByStudio: false, delayNotified: false,
      history: [...o.history, { type: "reschedule", from, to, at: Date.now() }]
    });
    notify(o.id, "Time changed for " + o.id, "Moved from " + from + " to " + to + ".");
    ctx.mode = null; ctx.newDate = null;
    return {
      text: "Step 4 · Time replaced\n" + from + "  →  " + to + "\n\nStep 5 · A notification was sent to you in this app.\nPlease also tell the studio so the team updates their calendar.",
      chips: [{ label: "Tell the studio on WhatsApp", url: waLink("Hello Cineflicks Media, order " + o.id + " was rescheduled from " + from + " to " + to + ".") }]
    };
  }
  if (ctx.mode === "refund") {
    if (/^(yes|y\b|confirm|ok)/.test(q)) {
      updateOrder(o.id, { status: "Refund requested" });
      notify(o.id, "Refund requested for " + o.id, "Your request is recorded. The studio confirms refunds on WhatsApp.");
      ctx.mode = null;
      return {
        text: "Step 5 · Refund request recorded and a notification was sent to you in this app.\nPlease also tell the studio so the team can process it.",
        chips: [{ label: "Tell the studio on WhatsApp", url: waLink("Hello Cineflicks Media, I would like a refund for order " + o.id + " (delayed).") }]
      };
    }
    ctx.mode = null; return null;
  }
  ctx.mode = null; return null;
}

function reply(raw) {
  const text = raw.trim(), q = text.toLowerCase();

  /* order ID in the message: step 1 */
  const idm = ORDER_RE.exec(text);
  if (idm) {
    const id = idm[0].toUpperCase(), o = findOrder(id);
    ctx.mode = null; ctx.newDate = null;
    if (!o) { ctx.order = null; return "I could not find order " + id + " on this device. Please check the ID, or contact us on WhatsApp " + BUSINESS.mobile + "."; }
    return runIntent(o, ctx.want || (/refund|cancel/.test(q) ? "refund" : /re-?schedul|change|postpone/.test(q) ? "reschedule" : "status"));
  }

  if (ctx.mode) {
    if (/^(stop|cancel|exit|no\b|never ?mind)/.test(q)) { ctx.mode = null; ctx.newDate = null; return "Okay, nothing was changed."; }
    const r = flow(text, q); if (r) return r;
  }

  if (/(notification|notify|alerts?)/.test(q)) return notificationsText();

  const want = /(re-?schedul|change (the |my )?(date|time|slot)|replace|postpone|shift)/.test(q) ? "reschedule"
    : /(refund|money back|cancel)/.test(q) ? "refund"
    : /(my order|order|status|track|delay|late|my booking|booking id|check)/.test(q) ? "status" : null;
  if (want) {
    const cur = findOrder(ctx.order);
    return cur ? runIntent(cur, want) : needOrder(want);
  }

  if (/(after|once i|what happens|deliver|album|next step)/.test(q)) {
    return "After you book a slot:\n1. You get an order ID, shown on the page and saved on this device.\n2. We confirm your slot on WhatsApp (" + BUSINESS.mobile + ").\n3. Send me your order ID any time to check your booking details, see if it is delayed, and check reschedule or refund eligibility.\n4. I can replace your time with an open slot, and you get a notification here for every update.\n5. Deliverables and delivery timing are agreed with the team on WhatsApp.\n\nServices we provide:\n" + SERVICES.map(s => "• " + s.name).join("\n");
  }
  if (/(about|business|company|who (are|is)|studio|tagline|location|address|hours|timing)/.test(q)) {
    return BUSINESS.name + " · " + BUSINESS.tagline + "\nWedding films and photography, maternity and baby shoots, product reviews, shop promotions and personal branding.\n" + BUSINESS.extra + "\n\n" + CONTACT_TEXT + "\nFor studio address and working hours, please message us on WhatsApp.";
  }
  if (/(slot|time|available|availability|free|open)/.test(q)) {
    const free = freeSlots();
    return "Open time slots: " + free.join(", ") + ".\nChoose a date and slot in the Book a slot section, then send the request. We confirm on WhatsApp.";
  }
  if (/(book|booking|reserve|how do i|request)/.test(q)) {
    return "To book: pick a service, a date, a time slot, then enter your name, 10-digit mobile number, email and event details, and press Request booking. You will get an order ID. We confirm on WhatsApp.";
  }
  if (/(service|package|shoot|wedding|maternity|baby|review|promotion|branding|event|price|cost)/.test(q)) {
    return "Our services:\n" + SERVICES.map(s => "• " + s.name + " — " + s.desc).join("\n") + "\nFor pricing, please contact us directly.";
  }
  if (/(contact|phone|number|whatsapp|email|mail|call|reach)/.test(q)) {
    return "You can reach us at:\n" + CONTACT_TEXT;
  }
  if (/\b(hi|hello|hey|namaste|vanakkam)\b/.test(q)) {
    return "Hello! I can help with our services, available slots, how to book, and your existing order: details, delay status, reschedule or refund eligibility.";
  }
  return "I can answer questions about our services, available slots, how to book, what happens after booking, and your order (send your order ID). For anything else, please contact us on WhatsApp or by email.";
}
function ask(text) {
  const t = text.trim();
  if (!t) return;
  chatLog.querySelectorAll(".chips-row").forEach(r => r.remove());
  addBubble(t, "me");
  setTimeout(() => {
    const r = reply(t), out = typeof r === "string" ? { text: r } : r;
    addBubble(out.text, "bot");
    if (out.chips && out.chips.length) addChips(out.chips);
  }, 250);
}
let greeted = false;
function openChat() {
  chatPanel.hidden = false;
  chatFab.setAttribute("aria-expanded", "true");
  if (!greeted) {
    greeted = true;
    addBubble("Hi, welcome to Cineflicks Media. How can I help you today?", "bot");
    const n = getNotifs().filter(x => !x.read).length;
    if (n) addBubble("You have " + n + " new notification" + (n > 1 ? "s" : "") + ". Tap Notifications to read.", "bot");
  }
  chatInput.focus();
}
function closeChat() {
  chatPanel.hidden = true;
  chatFab.setAttribute("aria-expanded", "false");
  chatFab.focus();
}
chatFab.addEventListener("click", () => chatPanel.hidden ? openChat() : closeChat());
$("#chatClose").addEventListener("click", closeChat);
chatForm.addEventListener("submit", e => {
  e.preventDefault();
  ask(chatInput.value);
  chatInput.value = "";
});
document.querySelectorAll("[data-q]").forEach(btn => btn.addEventListener("click", () => {
  const map = { services: "services", slots: "available slots", book: "how to book", contact: "contact",
    order: "my order", notifs: "notifications", after: "what happens after booking" };
  ask(map[btn.dataset.q]);
}));

/* Delay watcher: tells the customer in-app when one of their orders becomes delayed */
function watchDelays() { getOrders().forEach(checkDelayNotify); }
updateBadge();
watchDelays();
setInterval(watchDelays, 60000);
