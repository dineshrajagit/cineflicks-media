/* Site data and settings. Edit services, slots, contact details and policy here. */

const SERVICES = [
  { code: "WD", name: "Wedding Photo & Film", desc: "Cinematic wedding photography and video with highlight reels." },
  { code: "MT", name: "Maternity Shoot", desc: "Calm, intimate portraits to mark the journey to parenthood." },
  { code: "BS", name: "Baby Shoot", desc: "Newborn and baby sessions, studio or on location." },
  { code: "PR", name: "Product Reviews", desc: "Video and photo reviews that show products clearly." },
  { code: "SP", name: "Shop Promotions", desc: "Campaign content for shops, menus and seasonal offers." },
  { code: "PB", name: "Personal Branding", desc: "Profile-led content that builds trust and recognition." },
  { code: "EV", name: "Event Coverage", desc: "Live photo and video coverage for events and launches." }
];

const BOOKED = ["10:00 AM", "02:00 PM"];
const SLOTS = ["09:00 AM","10:00 AM","11:00 AM","12:00 PM","02:00 PM","04:00 PM","06:00 PM"];

const BUSINESS = {
  name: "Cineflicks Media",
  tagline: "Cinema · News · Events",
  mobile: "8072203834",
  email: "parameshwarankrishnan07@gmail.com",
  extra: "Social media services, digital marketing, personal branding ads and scalable Instagram growth are also available on request."
};
/* Edit these numbers to match the studio's real refund / reschedule policy */
const POLICY = {
  graceMinutes: 60,        // order counts as delayed this long after its scheduled time
  refundAfterDelayHours: 24, // refund is offered once an order is delayed this long
  maxReschedules: 2,       // time changes allowed per order
  minNoticeHours: 24       // notice needed for a normal (not delayed) reschedule
};
