/* Page logic: services grid, booking form, slot buttons, copy buttons */
const $ = (s, r = document) => r.querySelector(s);

/* Services */
const grid = $("#serviceGrid");
const select = $("#service");
select.innerHTML = '<option value="">Choose a service</option>' +
  SERVICES.map(s => `<option value="${s.code}">${s.name}</option>`).join("");

SERVICES.forEach(s => {
  const card = document.createElement("article");
  card.className = "service";
  card.innerHTML = `
    <h3>${s.name}</h3>
    <p>${s.desc}</p>
    <button type="button" data-service="${s.code}">Book this</button>`;
  grid.appendChild(card);
});

grid.addEventListener("click", e => {
  const b = e.target.closest("[data-service]");
  if (!b) return;
  select.value = b.dataset.service;
  $("#booking").scrollIntoView({ behavior: "smooth", block: "start" });
  $("#name").focus({ preventScroll: true });
});

/* Time slots */
let chosenSlot = "";
const slotWrap = $("#slots");
SLOTS.forEach(t => {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "slot";
  btn.textContent = t;
  btn.setAttribute("aria-pressed", "false");
  if (BOOKED.includes(t)) { btn.disabled = true; btn.title = "Already booked"; }
  btn.addEventListener("click", () => {
    chosenSlot = t;
    slotWrap.querySelectorAll(".slot").forEach(x => x.setAttribute("aria-pressed", String(x === btn)));
  });
  slotWrap.appendChild(btn);
});

/* Minimum date: today */
const dateInput = $("#date");
const now = new Date();
dateInput.min = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 10);

/* Copy buttons (falls back to selecting text if clipboard is refused) */
document.querySelectorAll("[data-copy]").forEach(btn => btn.addEventListener("click", () => {
  const text = btn.dataset.copy, original = btn.textContent;
  const done = () => { btn.textContent = "Copied"; setTimeout(() => btn.textContent = original, 1500); };
  try {
    navigator.clipboard.writeText(text).then(done).catch(() => { btn.textContent = "Select to copy"; });
  } catch (_) { btn.textContent = "Select to copy"; }
}));

/* Booking form validation (no server: confirmation is shown on the page) */
const form = $("#bookingForm"), msg = $("#formMsg");
function showMsg(text, type) {
  msg.textContent = text;
  msg.className = "msg show " + type;
}
form.addEventListener("submit", e => {
  e.preventDefault();
  const f = new FormData(form);
  const phone = String(f.get("phone") || "").replace(/[\s+-]/g, "").replace(/^91(?=\d{10}$)/, "");
  const email = String(f.get("email") || "").trim();
  const name = String(f.get("name") || "").trim();
  const svc = SERVICES.find(s => s.code === f.get("service"));

  if (!svc) return showMsg("Please choose a service.", "err");
  if (!f.get("date")) return showMsg("Please pick a date.", "err");
  if (!chosenSlot) return showMsg("Please choose a time slot.", "err");
  if (!name) return showMsg("Please enter your full name.", "err");
  if (!/^[6-9]\d{9}$/.test(phone)) return showMsg("Enter a valid 10-digit mobile number.", "err");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return showMsg("Enter a valid email address.", "err");

  const order = createOrder({ service: svc.code, serviceName: svc.name, date: String(f.get("date")), slot: chosenSlot, name, phone, email, notes: String(f.get("notes") || "").trim() });
  showMsg(`Request received for ${svc.name} on ${f.get("date")} at ${chosenSlot}. Your order ID is ${order.id}. We will confirm on WhatsApp at ${phone}.`, "ok");
  form.reset();
  chosenSlot = "";
  slotWrap.querySelectorAll(".slot").forEach(x => x.setAttribute("aria-pressed", "false"));
});

$("#year").textContent = new Date().getFullYear();
